import LP.clsMenu;

public class Main {
	/**
	 * A trav�s del main se llama a todos los metodos anteriores y los imprimimos por pantalla y los guardamos en los arraylist
	 * @param args
	 */

	public static void main(String[] args) {
		clsMenu.MenuPrincipal();

	}

}
